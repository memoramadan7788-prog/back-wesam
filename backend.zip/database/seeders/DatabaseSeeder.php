<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            PermissionSeeder::class,
            RoleCategorySeeder::class,
            RoleSeeder::class,
            AdminPermissionSeeder::class,
            AdminRoleSeeder::class,
            SuperAdminSeeder::class,
            JobCategorySeeder::class,
            SkillSeeder::class,
            CountrySeeder::class,
            SalaryRecordSeeder::class,
            DemoDataSeeder::class,
        ]);
    }
}
